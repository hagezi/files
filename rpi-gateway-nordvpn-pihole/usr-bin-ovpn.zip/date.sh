#!/bin/bash

# Date function
adddate() {
    echo "$(date +"%Y-%m-%d %T")"
}