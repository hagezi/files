SCRIPT=$(readlink -f "$0")
SCRIPTPATH=$(dirname "$SCRIPT")

cd "$SCRIPTPATH" || exit

. $SCRIPTPATH/variables.txt --source-only
. $SCRIPTPATH/date.sh --source-only

statusvpn=$(curl -s https://api.nordvpn.com/vpn/check/full | jq -r '.["status"]')
statusdns=$(if $(dig @127.0.0.1 nordvpn.com | grep -q 'NXDOMAIN'); then echo "ERROR"; else echo "OK"; fi)
server=$(shuf -n1 /tmp/nordvpn_hostname)
openvpnfile=$(sudo service vpngateway status | grep 'openvpn' | awk '{print $4}')
server_load=$(curl -s $SERVER_STATS_URL$server | jq -r '.[]')

echo "### VPN Status ###"
echo ""
echo "Connection: $statusvpn"
echo "DNS:        $statusdns"
echo "Server:     $server"
echo "OpenVPN:    $openvpnfile"
echo "Load:       $server_load %"
echo ""
echo "### Client Status ###"
curl -s https://ipapi.co/json | sed -e 's/^[[:space:]]*//' | sed 's/"//g' | sed 's/,//g' | sed 's/{//g' | sed 's/}//g'
echo ""
echo "### Service Status ###"
echo ""
sudo service vpngateway status | sed -e 's/^[[:space:]]*//' | grep 'Active:' |  sed 's/Active: //'
echo ""
echo "$(adddate)"
