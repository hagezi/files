#!/bin/bash

SCRIPT=$(readlink -f "$0")
SCRIPTPATH=$(dirname "$SCRIPT")

cd "$SCRIPTPATH" || exit

. variables.txt --source-only

# Delete existing rules
iptables -F

# Allow SSH (important)
iptables -A INPUT -p tcp --dport 22 -m conntrack --ctstate NEW,ESTABLISHED -m comment --comment "ssh" -j ACCEPT
iptables -A OUTPUT -p tcp --sport 22 -m conntrack --ctstate ESTABLISHED -m comment --comment "ssh" -j ACCEPT

# Routing / Forwarding
iptables -t nat -A POSTROUTING -o tun0 -m comment --comment "nat" -j MASQUERADE
iptables -A FORWARD -i tun0 -o eth0 -m state --state RELATED,ESTABLISHED -m comment --comment "vpn > lan" -j ACCEPT
iptables -A FORWARD -i eth0 -o tun0 -m comment --comment "lan > vpn" -j ACCEPT

# Allow vpn traffic, icmp, lan, ntp
iptables -A OUTPUT -o tun0 -m comment --comment "vpn" -j ACCEPT
iptables -A OUTPUT -o eth0 -p icmp -m comment --comment "icmp" -j ACCEPT
iptables -A OUTPUT -d $LOCAL_NETWORK -o eth0 -m comment --comment "lan" -j ACCEPT
iptables -A OUTPUT -o eth0 -p udp -m udp --dport 1194 -m comment --comment "vpn traffic" -j ACCEPT
iptables -A OUTPUT -o eth0 -p udp -m udp --dport 123 -m comment --comment "ntp" -j ACCEPT

# Allow NordVPN IPs when vpn tunnel is down (killswitch active) to retrieve ovpn files and recommended servers before reconnect
iptables -A OUTPUT -d $NORDVPN_DNS1 -m comment --comment "nordvpn dns" -j ACCEPT
iptables -A OUTPUT -d $NORDVPN_DNS2 -m comment --comment "nordvpn dns" -j ACCEPT
iptables -A OUTPUT -d $NORDVPN_COM1 -m comment --comment "nordvpn" -j ACCEPT
iptables -A OUTPUT -d $NORDVPN_COM2 -m comment --comment "nordvpn" -j ACCEPT
iptables -A OUTPUT -d $NORDVPN_CDN1 -m comment --comment "nordcdn" -j ACCEPT
iptables -A OUTPUT -d $NORDVPN_CDN2 -m comment --comment "nordcdn" -j ACCEPT

# Killswitch
iptables -A OUTPUT -o eth0 -j DROP
iptables -I FORWARD -i eth0 ! -o tun0 -j DROP
