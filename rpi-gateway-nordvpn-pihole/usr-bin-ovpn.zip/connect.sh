#!/bin/bash
echo "#SERVER=xx123.nordvpn.com" > /usr/bin/ovpn/server.txt
echo "COUNTRY=$1" > /usr/bin/ovpn/country.txt
sudo service vpngateway restart
sleep 10
/usr/bin/ovpn/health.sh > /var/www/html/rpistatsvpn.txt
